/* 
 * © 2017 GWare Solutions IPTV UI
 * author SWD
 */

var GWarePlayer = function(){
	this.name = _playerGetName();	
	this.getMAC = _playerGetMAC;
};