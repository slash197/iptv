<?php

require_once('unixtime.php');

$time = new Time;
$time->utime();

?>