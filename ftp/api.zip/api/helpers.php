<?php 
/**
 * @functions helpers
 */
function ipAddress() {
	if(isset($_SERVER["HTTP_CF_CONNECTING_IP"])){
            //If it does, assume that PHP app is behind Cloudflare.
            $ipAddress = $_SERVER["HTTP_CF_CONNECTING_IP"];
        } else{
            //Otherwise, use REMOTE_ADDR.
            $ipAddress = $_SERVER['REMOTE_ADDR'];
        }
	return $ipAddress;
}

function checkuser($username, $password){
	global $db;
	$password = base64_encode($password);

	$sql="SELECT c.*,ct.name city,co.name country FROM customers c
		  JOIN cities ct on c.billing_city=ct.id
		  JOIN countries co on c.billing_country=co.id
	      WHERE c.username='$username' AND c.password='$password'";
	$result = $db->query($sql);
	if($result->num_rows>0)
		return mysqli_fetch_object($result);
		else
			return false;
}


function check_already_exist($customer_id,$uuid, $model){
	global $db;
	$sql="SELECT * FROM customer_to_devices 
	      WHERE uuid='".$uuid."' AND model='".$model."' AND customer_id='$customer_id'";
	$result  = $db->query($sql);

	if($result->num_rows>0)
		return true;
	else
		return false;
}

function get_devices($userid){
	global $db;
	$sql="SELECT cd.* FROM customer_to_devices cd
		  LEFT JOIN customers c on c.id=cd.customer_id
	      WHERE cd.customer_id='$userid'";
	return $result  = $db->query($sql);
}


function check_if_any_expired_devices($userid){
	global $db;
	
	$sql="SELECT * FROM customer_to_devices 
	      WHERE customer_id='$userid' AND valid <= '".time()."' LIMIT 1";
	
	$result  = $db->query($sql);
	return $result;
}


function insert($table,$data){
	global $db;
	$fields  = implode(',', array_keys($data));
    $values  = implode("','", array_values($data));
    $values = "'".$values."'";
    $sql = "INSERT INTO ".$table."(".$fields.") Values "."(".$values.")";
	$result = $db->query($sql);
	if($result){
    	return true;
	} else {
    	return false;
	}
}

function update($table,$data,$uuid){
	global $db;
    $set_statement="";
    foreach ($data as $key => $value) {
    	 $set_statement.=$key ."='". $value."',";
    }

    $sql = "UPDATE ".$table." SET ".rtrim($set_statement,',')." WHERE uuid='".$uuid."'";
	$result = $db->query($sql);
	if($result){
    	return true;
	} else {
    	return false;
	}
}

function delete_device($table,$data_array){
	global $db;
	$field  = implode(',', array_keys($data_array));
    $value  = implode(",", array_values($data_array));
	$sql = "Delete from ". $table. " where ". $field ."='".$value."'";
	$result = $db->query($sql);
	if($result){
    	return true;
	} else {
    	return false;
	}
}

function encrypt($data, $key)
{
  return base64_encode(openssl_encrypt($data, 'AES-128-ECB', $key, $options = OPENSSL_RAW_DATA, $iv = ''));
}

function decrypt($data, $key)
{
  return openssl_decrypt(base64_decode($data), 'AES-128-ECB', $key, $options = OPENSSL_RAW_DATA, $iv = '');
}


function getCountry($countryname){
	global $db;
	
	$sql="SELECT id FROM countries
	      WHERE name='$countryname'";
	$result = $db->query($sql);
	if($result->num_rows>0)
		return mysqli_fetch_object($result);
		else
			return false;
}

function uploadToServer($filename,$localFilePath,$remoteFilePath){
	// FTP server details
	$ftp_host   = 'ftp.ams.9662C.etacdn.net';
	$ftp_username = 'vissionent+3iptv@gmail.com';
	$ftp_password = '12k-skkw-2WEE_MAS';

	// open an FTP connection
	$conn_id = ftp_connect($ftp_host) or die("Couldn't connect to $ftp_host");

	// login to FTP server
	$ftp_login = ftp_login($conn_id, $ftp_username, $ftp_password);

	// local & server file path
	$remoteFilePath = '/gomiddleware/'. $remoteFilePath.'/'.$filename;
	
	//move_uploaded_file ($filename , $localFilePath);
	// try to upload file
	if(ftp_put($conn_id, $remoteFilePath, $localFilePath, FTP_BINARY)){
	   // echo "File transfer successful - $localFilePath";
	}else{
	    //echo "There was an error while uploading $localFilePath";
	}
	// close the connection
	ftp_close($conn_id);
}
?>