<?php

require_once('removeDevice.php');

$device = new Devices();

$device->logoutDevice();

?>