<?php

require_once('addDevices.php');

$device = new Devices();

$device->addDevice();

?>