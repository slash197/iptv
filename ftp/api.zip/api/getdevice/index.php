<?php
require_once('devices.php');

$device = new Devices();

$device->getDevices();

?>