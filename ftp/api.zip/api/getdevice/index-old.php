<?php

require_once('getdevice.php');

$getdevice = new Getdevice;
$getdevice->gdevice();

?>