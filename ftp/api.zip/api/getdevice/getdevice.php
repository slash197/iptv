<?php
class Getdevice {
     public function gdevice(){
		echo '{"devices":[{"resellerId":"0","valid":"1562904846","city":"South Yarra","state":"Victoria","country":"Australia","ip":"101.116.100.75","type":"_ATV","model":"Safari","uuid":"5aac57c8310229c2a68b20502d7c5025"},
		{"resellerId":"0","valid":"1573697952","city":"South Yarra","state":"Victoria","country":"Australia","ip":"101.116.100.75","type":"_bebTV","model":"Safari","uuid":"a45a39b06323ade1c7e077e801aab0171"},
		{"resellerId":"0","valid":"1573697952","city":"South Yarra","state":"Victoria","country":"Australia","ip":"101.116.100.75","type":"_vebTV","model":"Safari","uuid":"v45a39b06323ade1c7e077e801aab0171"},
		{"resellerId":"0","valid":"1573697952","city":"South Yarra","state":"Victoria","country":"Australia","ip":"101.116.100.75","type":"_WebTV","model":"Safari","uuid":"v45a39b06323ade1c7e077e801aab0171"},
		{"resellerId":"0","valid":"1573697952","city":"South Yarra","state":"Victoria","country":"Australia","ip":"101.116.100.75","type":"_WebTV","model":"Chrome","uuid":"45a39b06323ade1c7e077e801aab0171"}]}';
	}
 }
?>

