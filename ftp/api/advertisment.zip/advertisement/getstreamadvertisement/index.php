<?php
/**
 * @index 
 * @author  Sunil Dongol <sunil.dongol@gmail.com>
 */

require_once('../advertisement.php');

$advs = new Advertisement();
$advs->displayPrerollTickerOverlay();

?>