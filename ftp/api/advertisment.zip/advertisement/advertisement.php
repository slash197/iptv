<?php
/**
 * @class Advertisement
 * @author  Sunil Dongol <sunil.dongol@gmail.com>
 */

require_once('../../db-connection.php');
require_once('../../helpers.php');

class Advertisement{
    public function __construct(){
       
    }
    //endpoint url
    //http://gomiddleware.com/api/advertisement/gethomescreenadvertisementduo?orientation=vertical&userId=16061807&resellerId=0&deviceModel=_WebTV&cmsService=gomiddleware&crmService=gomiddlewareTV&city=Richmond&state=Victoria&country=Australia
    public function displayBanners(){
        global $db;
        $orientation=$_GET['orientation'];
        $userId=$_GET['userId'];
        $resellerId=$_GET['resellerId'];
        $deviceModel=$_GET['deviceModel'];
        $city=$_GET['city'];
        $state=$_GET['state'];
        $countryname=$_GET['country'];

        //get country id from country name 
        $country=getCountry($countryname);
        if($country){
            //get two random banners according to country 
            $sql="SELECT * FROM advertisement a
                  JOIN advertisements_exclude_include_countries ac
                  on a.id=ac.advertisement_id 
                  WHERE ac.country_id='$country->id' AND a.type='banner'
                  ORDER BY RAND()
                  LIMIT 2";  // 14 Australia 
            $result = $db->query($sql);
            $output=array();
            $i=1;
           
            if($result->num_rows>0){
                while($row = $result->fetch_array())
                {
                    $rows[] = $row;
                }
                foreach ($rows as $row) {
                    if($i==2){
                        $output1=array(
                                  "url$i"=>$row['url'],
                                  "campaignemail$i"=>$row['campaign_email'],
                                  "campaigntext$i"=>$row['text'],
                                  "campaignstream$i"=> $row['stream_url'],
                                  "campaignbackdrop$i"=> $row['backdrop'],
                                  "campaignenabled$i"=> 1,
                                  "campaignid$i"=>$row['id']
                            );
                         $output=array_merge($output,$output1);
                    }else{
                        $output1=array(
                                  "url"=>$row['url'],
                                  "campaignemail"=> $row['campaign_email'],
                                  "campaigntext"=> $row['text'],
                                  "campaignstream"=> $row['stream_url'],
                                  "campaignbackdrop"=> $row['backdrop'],
                                  "campaignenabled"=> 0,
                                  "campaignid"=> $row['id']
                            );
                        $output=array_merge($output,$output1);
                    }
                    $i++;
                }
            }
            else{
                $error['status'] = 'error';
                $error['code'] = -5;
                $error['message'] ='No banners could be found';
                $output= $error;
            }
        }else{
            $error['status'] = 'error';
            $error['code'] = -6;
            $error['message'] ='User Country could not be found';
            $output= $error;
        }
        echo json_encode($output);
    }

    //endpoint url 
    // api/advertisement/getstreamadvertisement?contentName=Sony&contentType=channel&contentId=34&userId=11&resellerId=0&deviceModel=_WebTV&cmsService=gomiddleware&crmService=gomiddlewareTV&city=Melbourne&state=Victoria&country=Australia
    public function displayPrerollTickerOverlay(){
        global $db;
        $contentName=$_GET['contentName'];
        $contentType=$_GET['contentType'];
        $contentId=$_GET['contentId'];
        $userId=$_GET['userId'];
        $resellerId=$_GET['resellerId'];
        $deviceModel=$_GET['deviceModel'];
        $cmsService=$_GET['cmsService'];
        $crmService=$_GET['crmService'];
        $city=$_GET['city'];
        $state=$_GET['state'];
        $countryname=$_GET['country'];

        //get country id from country name 
        $country=getCountry($countryname);
        $preroll=array();
        $ticker=array();
        $overlay=array();

        if($country){
            //get one random preroll according to country 
            $sql="SELECT * FROM advertisement a
                  JOIN advertisements_exclude_include_countries ac
                  on a.id=ac.advertisement_id 
                  WHERE ac.country_id='$country->id' AND a.type='preroll'
                  ORDER BY RAND()
                  LIMIT 1";   
            $result = $db->query($sql);
            if($result->num_rows>0){
                while($row = $result->fetch_array())
                {
                    $rows[] = $row;
                }
                foreach ($rows as $row) {
                  $preroll=array('url'=>$row['url'],
                                 'show_time'=>$row['show_time']);
                }
            }

            //get one random ticker according to country 
            $sql="SELECT * FROM advertisement a
                  JOIN advertisements_exclude_include_countries ac
                  on a.id=ac.advertisement_id 
                  WHERE ac.country_id='$country->id' AND a.type='ticker'
                  ORDER BY RAND()
                  LIMIT 1";   
            $result = $db->query($sql);
            if($result->num_rows>0){
                while($row = $result->fetch_array())
                {
                    $rows[] = $row;
                }
                foreach ($rows as $row) {
                  $ticker=array('text'=>$row['text'],
                                'show_time'=>$row['show_time']);
                }
            }

            //get one random ticker according to country 
            $sql="SELECT * FROM advertisement a
                  JOIN advertisements_exclude_include_countries ac
                  on a.id=ac.advertisement_id 
                  WHERE ac.country_id='$country->id' AND a.type='overlay'
                  ORDER BY RAND()
                  LIMIT 1";   
            $result = $db->query($sql);
            if($result->num_rows>0){
                while($row = $result->fetch_array())
                {
                    $rows[] = $row;
                }
                foreach ($rows as $row) {
                  $overlay=array('type'=>NULL,
                                 'url'=>$row['image'],
                                 'show_time'=>$row['show_time']);
                }
            }

            echo json_encode(array('servertime'=>date('Y-m-d H:i:s',time()),
                                  'preroll'=>$preroll,
                                  'ticker'=>$ticker,
                                  'overlay'=>$overlay)
            );
        }else{
            $error['status'] = 'error';
            $error['code'] = -6;
            $error['message'] ='User Country could not be found';
            echo json_encode($error);
        }
    }
}
?>