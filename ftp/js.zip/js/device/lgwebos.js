GWareConfig.keyCodes = {
   1003: 'Back',
    461: 'Back',
	 13: 'OK',

	 37: 'Left',
	 38: 'Up',
	 39: 'Right',
	 40: 'Down',

	 48: '0',
	 49: '1',
	 50: '2',
	 51: '3',
	 52: '4',
	 53: '5',
	 54: '6',
	 55: '7',
	 56: '8',
	 57: '9',

	 34: 'ChannelDown',
	 33: 'ChannelUp',
	457: 'Info',
	458: 'EPG',

	403: 'Red',
	404: 'Green',
	405: 'Yellow',
	406: 'Blue',

	412: 'Rewind',
	417: 'Forward',
	413: 'Stop',
	415: 'Play',
	
	 19: 'Pause',
	416: 'Record',
	
	999: 'PowerWake'
};